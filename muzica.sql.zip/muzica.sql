-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2023 at 10:10 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `muzica`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `product_id`, `quantity`, `added_at`) VALUES
(5, 0, 8, 100, '2023-05-23 15:59:43'),
(6, 0, 8, 1, '2023-05-23 16:01:47'),
(7, 8, 8, 1, '2023-05-23 16:01:51'),
(8, 8, 8, 1, '2023-05-23 16:02:03'),
(15, 3, 4, 1, '2023-05-23 16:54:17'),
(16, 1, 16, 1, '2023-05-23 16:54:28'),
(17, 9, 3, 1, '2023-05-24 18:00:51');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id_c` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id_c`, `name`, `email`, `message`) VALUES
(1, 'Ionuttt', 'burzu@yahoo.com', 'imi plac produsele'),
(2, 'Burz Ioan', 'r7nxtuzb5g@waterisgone.com', 'as');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id_p` int(11) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `description` text NOT NULL,
  `picture` varchar(256) NOT NULL,
  `stock` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id_p`, `p_name`, `price`, `description`, `picture`, `stock`, `category`, `brand`) VALUES
(3, 'Acoustic Guitar Set', 120, 'A begginers set', 'imaginiproduse/seturi-chitara-clasica.jpg', 5, 'Chitara', 'Classical'),
(4, 'Electric Guitar Set', 150, 'A begginers set', 'imaginiproduse/3018224_big.jpg', 15, 'Chitara', 'Vas'),
(5, 'Kids Guitar', 100, 'Kids guitar', 'imaginiproduse/175880-1-bontempi-chitara-electrica-albastru-1631789814333353.jpg', 10, 'Chitara', 'Dantem'),
(6, 'Ibanez Steve Vai WH', 250, 'JEM Premium Steve Vai signature\r\nBody: Alder\r\nNeck: Maple\r\nScale: 648 mm\r\nNeck mounting: Bolted\r\nNeck profile: Wizard\r\nNut width: 43 mm\r\nFretboard: Ebony\r\nFretboard radius: 400 mm\r\nTree of life fretboard inlay\r\n24 Jumbo waistbands with premium waistband edge treatment\r\nPickups: DiMarzio Evolution humbucker (bridge), Evolution single-coil (middle) and Evolution humbucker (neck)\r\nSound and volume controls\r\n5-Way switch\r\nEdge tremolo\r\nGolden hardware\r\nColour: White\r\nIncludes gigbag', 'imaginiproduse/71A1yCXw+iL.jpg', 5, 'Chitara', 'Ibanez'),
(8, 'Strandberg Boden Metal BL', 350, 'Djent electric guitar', 'imaginiproduse/1659435072bd6tct-21s-m-f-bl_1.jpg', 3, 'Chitara', 'Strandberg'),
(9, 'Gibson Les Paul 59 YL', 320, 'Electric guitar for rock.', 'imaginiproduse/istockphoto-157772620-612x612.jpg', 8, 'Chitara', 'Gibson'),
(10, ' Schecter Platinum Satin BK', 350, 'Electric guitar for metal/thrash metal.', 'imaginiproduse/14323898_800.jpg', 9, 'Chitara', 'Schecter'),
(11, 'Fender American Professional P OG', 300, 'Electric Bass', 'imaginiproduse/fender-american-professional-ii-p-bass-mn-3tsb.jpg', 13, 'Chitara', 'Fender'),
(12, 'ESP LTD  Black Metal BK', 280, 'Electric Bass for metal', 'imaginiproduse/esp-ltd-ap-4-black-metal-blks.jpg', 18, 'Chitara', 'ESP LTD'),
(14, 'ESP LTD Black Metal BK', 240, 'Electric Bass for metal', 'imaginiproduse/esp-ltd-f4-black-metal-blks.jpg', 4, 'Chitara', 'ESP LTD'),
(15, ' Sonor Stage BK', 2999, 'harware finish chrome plated configuration without attachment on the bass drum name SQ1 322 series SQ1 material Birch description Sound Set SQ1 STAGE the set contains 1 x Bass Drum', 'imaginiproduse/set-tobe-acustice-sonor-sq1-studio-gt-black-1.jpg', 3, 'Tobe', 'Sonor'),
(16, 'Kids Drums', 150, 'Complete Drum Set For Kids Perfect For Drummers From 3 Years Shell Material: Hardwood Black Hardware Drum Shell With Robust Finish Color: Sparkle Azure Consists Of: 16 â€žX 12â€¨ Drum 08 â€žX 05â€ Tom Tom Drum Small Drum 10 x 04 Stand Hi-Hat Stand Pedal Seat 1 Pair of Beats', 'imaginiproduse/Capture.JPG-2.jpg', 4, 'Tobe', 'Millenium'),
(17, ' Basix Xenon AMBK', 240, 'Professional 6-ply poplar wood acoustic drum set\r\n\r\nlarge drum: 20\"x16\"\r\nsize1: 10\"x07\"\r\ntam2: 12\"x08\"\r\nboiler: 14\"x12\"\r\nsmall drum 14\"x5\"\r\nincludes: big drum pedal, snare stand, snare boom stand, small snare stand, snare stand\r\nfinish: amber black fade', 'imaginiproduse/set-tobe-acustice-basix-xenon-f800564-amber-black-fade.jpg', 7, 'Tobe', 'BASIX '),
(18, ' Roland BK', 5130, 'Full size drum pads The toms and kick drum are made of wood Premier (Small Drum) made of stainless steel Chairs with ergonomic and natural design It contains 728 sounds 55 drum presets 45 user kits It features prismatic sound modulation technology Includes Bluetooth v4.2 technology Includes sample reverb (IR) Includes TD-27 drum module The possibility of importing 500 WAV samples (maximum duration: 24 minutes, mono format) Includes an SD card slot (SDHC compatible) Quick Record function Connectors: Multipin connector (Trigger Input) for 8 pads Includes 4 6.3 mm jack inputs for additional pads Includes 3 digital trigger inputs for Roland digital pads with \"multi-sensor\" technology It includes 2 main outputs with 6.3 mm jack connectors Includes 2 \"Direct Out\" outputs with 6.3 mm jack connectors Includes 1 stereo headphone output with 6.3 mm jack connector Includes 1 AUX stereo input with 3.5 mm jack connector Includes 1 footswitch input with 6.3 mm jack connector MIDI I/O USB type B USB MIDI Configuration: 1x Kick Drum (KD-200) 20\"x16\" 1x Digital Snare Drum (PD-140DS) with 14\"x5\" Mesh Drum Heads 1x Tom (PDA-100) with two zones 10\"x7\" 1x Tom (PDA-120) with two zones 12\"x8\" 1x Boiler (PDA-140F) with two zones 14\"x13\" 1x 12\" dual-zone spindle and VH-10 foot controller 1x Cinel (CY-14R-T) with two zones and \"Choke\" function of 14\" 1x Cinel (CY-16R-T) with two zones and 16\" \"Choke\" function 1x 18\" \"Laugh\" type digital dinner table The set includes 2 \"combo cymbal/tom\" stands, 1 giraffe stand and a multiclamp for mounting the drum module.', 'imaginiproduse/5511111_big.jpg', 2, 'Tobe', 'Roland'),
(19, 'Yamaha HTRD', 490, 'Rydeen Hot Red acoustic drum set 22\"x16\" bass drum, 16\"x15\" drum, 12\"x8\"/10\"x7\" toms, 14\"x5.5\" prem, HW680 hardware, Paiste 14-16-20 inch cymbal set', 'imaginiproduse/5313129_big.jpg', 9, 'Tobe', 'Yamaha'),
(20, 'Sonor Vintage VT', 690, 'chrome hardware finish configuration without attachment on the big drum name Vintage series Three 22 shell set Vintage series Beech material Vintage construction description VT15 Three 22 shells NM', 'imaginiproduse/set-tobe-acustice-sonor-three-22-rosewood.jpg', 4, 'Tobe', 'Sonor'),
(21, 'Behringer XD8USB BK', 780, 'BEHRINGER XD8USB electronic drum set. Pad for snare drum with two hitting zones. The bass drum pad includes the pedal. Sounds module with 123 sounds, 10 preset and 5 editable drum kits, study tracks, metronome. USB interface, auxiliary input, audio output for line/headset. The package includes sticks.', 'imaginiproduse/set-tobe-digitale-behringer-xd8usb.jpg', 5, 'Tobe', 'Behringer'),
(22, 'Yamaha RDP2F5 Rydeen BK', 540, 'HS650WA Hi-Hat Stand Small drum stand SS650WA 2x Cinel Stand CS665A Kick drum pedal FP7210A Paiste 101 dinner set consisting of: Hi-Hat 14\", Crash 16\", Ride 20\"', 'imaginiproduse/set-tobe-acustice-yamaha-rdp2f5-rydeen-blg.jpg', 8, 'Tobe', 'Yamaha'),
(23, 'Millenium HD-120 BK', 480, 'Complete electronic drum set for beginners Due to its compact dimensions and short distances, it is also ideal for children They save a lot of space - required footprint: 100 x 60 cm It includes: 12 drum kits Metronome 40-240 bpm 3.5 mm jack line output 3.5mm stereo jack headphone output Stereo 3.5 mm Aux-In jack USB MIDI Includes cables, seat, headphones, sticks, stick holder and power supply (100-240V) Set configuration: 1 x 07\" Snare drum pad 3 x 07\" Tom Tom Pads 1 x Bass drum controller 3 x 09\" Cymbal pads 1 x Hi-hat controller Drum rack', 'imaginiproduse/set-tobe-electronice-millenium-hd-120.jpg', 7, 'Tobe', 'Millenium'),
(24, 'Pearl Export EXX725SBR BK', 640, 'Built to capture the look, sound and feel of top gear at an affordable price. After 30 years as some of the best selling drum sets in the world, Pearl Export is a name every drummer knows. This series offers excellent value for money for beginner drummers and beyond.', 'imaginiproduse/1773578_big.jpg', 3, 'Tobe', 'Pearl'),
(25, 'Juarez Obra Complete Full BK', 530, 'Have you or someone that you are close to been pushing back your dream of playing thedrums? Well, wait no longer! The JuÃ¢rezDrum Set JRD500 allows beginners and experts alike to sound and look skilled and impressive. Preform, record, play in that band, or even just jam along to your favourite tunes. The possibilities are endless your dreams are within reach!', 'imaginiproduse/71usv6FMO7L._SL1500_.jpg', 5, 'Tobe', 'Juarez'),
(26, 'Pearl Roadshow X Fusion BL', 820, 'The Pearl Roadshow X Drum Kit is the best starter kit on the market! If your beginning drums and need the best value budget kit, the Pearl Roadshow Kit is for you.  Formed from multiple plies of bonded hardwood, the drum shells are molded to create a single air resonance chamber to project a note when the drum head is struck. Roadshow bass drum, tom toms, and snare are made of a 9-ply Poplar shell for optimum tonal power.', 'imaginiproduse/Pearl-Roadshow-X-Fusion-Plus-Drum-Kit-W-Zildjian-Cymbals-Royal-Blue-Metallic-002.jpg', 1, 'Tobe', 'Pearl'),
(27, 'Schecter Synyster Gates BK', 670, 'Synyster Gates (Avenged Sevenfold) Signature Model Mahogany body Solid mahogany neck with carbon fibre reinforcement rods Ebony fretboard Pearloid \"Syn\" fretboard inlays \"Death Bat\" inlay on the 12th fret Ultra Thin C neck profile Fretboard radius: 406 mm (16\") Scale: 648 mm Nut width: 41.3 mm Floyd Rose 1500 Series nut 24 X-Jumbo stainless steel frets Pickups: Sustainiac (bridge)- & Schecter USA Synyster Gates Signature (neck) humbuckers Volume and tone controls 3-Way pickup selector switch 2-Way switch for Sustainiac mode 9 V Block battery Floyd Rose 1500 Series tremolo Black hardware Grover Rotomatic 18:2 machine heads Colour: Gloss Black with Silver Pin Stripes', 'imaginiproduse/355911_0.jpg', 7, 'Chitara', 'Schecter'),
(28, 'Fender Jimi Hendrix Strat WH', 980, 'Artist Signature Series - Jimi Hendrix model Alder body Maple Neck C-Neck profile Maple fretboard 9.5 \"Radius 21 Medium jumbo frets Scale: 648 mm Micarta saddle Pickups: 3 American Vintage 65 single coils 5-Way switch Synchronised tremolo White \"aged\" plastic parts Reversed headstock Jimi Hendrix signature rear headstock Strings: Fender 250R .010 - .046 (Art 104112) Colour: Olympic White Gigbag included', 'imaginiproduse/10727307_800.jpg', 1, 'Chitara', 'Fender');

-- --------------------------------------------------------

--
-- Table structure for table `tari`
--

CREATE TABLE `tari` (
  `id_t` int(11) NOT NULL,
  `denumire` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tari`
--

INSERT INTO `tari` (`id_t`, `denumire`) VALUES
(1, 'Afghanistan'),
(2, 'Albania'),
(3, 'Algeria'),
(4, 'Andorra'),
(5, 'Angola'),
(6, 'Antigua and Barbuda'),
(7, 'Argentina'),
(8, 'Armenia'),
(9, 'Australia'),
(10, 'Austria'),
(11, 'Azerbaijan'),
(12, 'Bahamas'),
(13, 'Bahrain'),
(14, 'Bangladesh'),
(15, 'Barbados'),
(16, 'Belarus'),
(17, 'Belgium'),
(18, 'Belize'),
(19, 'Benin'),
(20, 'Bhutan'),
(21, 'Bolivia'),
(22, 'Bosnia and Herzegovina'),
(23, 'Botswana'),
(24, 'Brazil'),
(25, 'Brunei'),
(26, 'Bulgaria'),
(27, 'Burkina Faso'),
(28, 'Burundi'),
(29, 'Cabo Verde'),
(30, 'Cambodia'),
(31, 'Cameroon'),
(32, 'Canada'),
(33, 'Central African Republic'),
(34, 'Chad'),
(35, 'Chile'),
(36, 'China'),
(37, 'Colombia'),
(38, 'Comoros'),
(39, 'Congo'),
(40, 'Costa Rica'),
(41, 'Croatia'),
(42, 'Cuba'),
(43, 'Cyprus'),
(44, 'Czech Republic'),
(45, 'Denmark'),
(46, 'Djibouti'),
(47, 'Dominica'),
(48, 'Dominican Republic'),
(49, 'East Timor'),
(50, 'Ecuador'),
(51, 'Egypt'),
(52, 'El Salvador'),
(53, 'Equatorial Guinea'),
(54, 'Eritrea'),
(55, 'Estonia'),
(56, 'Eswatini'),
(57, 'Ethiopia'),
(58, 'Fiji'),
(59, 'Finland'),
(60, 'France'),
(61, 'Gabon'),
(62, 'Gambia'),
(63, 'Georgia'),
(64, 'Germany'),
(65, 'Ghana'),
(66, 'Greece'),
(67, 'Grenada'),
(68, 'Guatemala'),
(69, 'Guinea'),
(70, 'Guinea-Bissau'),
(71, 'Guyana'),
(72, 'Haiti'),
(73, 'Honduras'),
(74, 'Hungary'),
(75, 'Iceland'),
(76, 'India'),
(77, 'Indonesia'),
(78, 'Iran'),
(79, 'Iraq'),
(80, 'Ireland'),
(81, 'Israel'),
(82, 'Italy'),
(83, 'Jamaica'),
(84, 'Japan'),
(85, 'Jordan'),
(86, 'Kazakhstan'),
(87, 'Kenya'),
(88, 'Kiribati'),
(89, 'Korea, North'),
(90, 'Korea, South'),
(91, 'Kosovo'),
(92, 'Kuwait'),
(93, 'Kyrgyzstan'),
(94, 'Laos'),
(95, 'Latvia'),
(96, 'Lebanon'),
(97, 'Lesotho'),
(98, 'Liberia'),
(99, 'Libya'),
(100, 'Liechtenstein'),
(101, 'Lithuania'),
(102, 'Luxembourg'),
(103, 'Madagascar'),
(104, 'Malawi'),
(105, 'Malaysia'),
(106, 'Maldives'),
(107, 'Mali'),
(108, 'Malta'),
(109, 'Marshall Islands'),
(110, 'Mauritania'),
(111, 'Mauritius'),
(112, 'Mexico'),
(113, 'Micronesia'),
(114, 'Moldova'),
(115, 'Monaco'),
(116, 'Mongolia'),
(117, 'Montenegro'),
(118, 'Morocco'),
(119, 'Mozambique'),
(120, 'Myanmar'),
(121, 'Namibia'),
(122, 'Nauru'),
(123, 'Nepal'),
(124, 'Netherlands'),
(125, 'New Zealand'),
(126, 'Nicaragua'),
(127, 'Niger'),
(128, 'Nigeria'),
(129, 'North Macedonia'),
(130, 'Norway'),
(131, 'Oman'),
(132, 'Pakistan'),
(133, 'Palau'),
(134, 'Panama'),
(135, 'Papua New Guinea'),
(136, 'Paraguay'),
(137, 'Peru'),
(138, 'Philippines'),
(139, 'Poland'),
(140, 'Portugal'),
(141, 'Qatar'),
(142, 'Romania'),
(143, 'Russia'),
(144, 'Rwanda'),
(145, 'Saint Kitts and Nevis'),
(146, 'Saint Lucia'),
(147, 'Saint Vincent and the Grenadines'),
(148, 'Samoa'),
(149, 'San Marino'),
(150, 'Sao Tome and Principe'),
(151, 'Saudi Arabia'),
(152, 'Senegal'),
(153, 'Serbia'),
(154, 'Seychelles'),
(155, 'Sierra Leone'),
(156, 'Singapore'),
(157, 'Slovakia'),
(158, 'Slovenia'),
(159, 'Solomon Islands'),
(160, 'Somalia'),
(161, 'South Africa'),
(162, 'South Sudan'),
(163, 'Spain'),
(164, 'Sri Lanka'),
(165, 'Sudan'),
(166, 'Suriname'),
(167, 'Sweden'),
(168, 'Switzerland'),
(169, 'Syria'),
(170, 'Taiwan'),
(171, 'Tajikistan'),
(172, 'Tanzania'),
(173, 'Thailand'),
(174, 'Togo'),
(175, 'Tonga'),
(176, 'Trinidad and Tobago'),
(177, 'Tunisia'),
(178, 'Turkey'),
(179, 'Turkmenistan'),
(180, 'Tuvalu'),
(181, 'Uganda'),
(182, 'Ukraine'),
(183, 'United Arab Emirates'),
(184, 'United Kingdom'),
(185, 'United States'),
(186, 'Uruguay'),
(187, 'Uzbekistan'),
(188, 'Vanuatu'),
(189, 'Vatican City'),
(190, 'Venezuela'),
(191, 'Vietnam'),
(192, 'Yemen'),
(193, 'Zambia'),
(194, 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_u` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passw` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `street` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `role` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_u`, `email`, `passw`, `first_name`, `last_name`, `street`, `city`, `country`, `role`) VALUES
(1, 'joldescosti@yahoo.com', 'root', 'Costin', 'Joldes', 'Strada Primaverii nr 9', 'Campeni', 'Romania', 'admin'),
(3, 'burzioan@yahoo.com', 'root', 'Burz', 'Ionut', 'Strada Horea 22', 'Campeni', 'Afghanistan', ''),
(4, 'virgil.berindeie@cniancu.ro', '1234', 'Gilu', 'Berindeie', 'Peles', 'Timpeni', 'Romania', ''),
(5, 'virgil.berindeie@cniancu.ro', '1234', 'Gilu', 'Berindeie', 'Peles', 'Campeni', 'Romania', ''),
(6, 'cucubau@gmail.com', '1234', 'cucubau', 'baubau', 'street of hope', 'timpeni', 'Romania', ''),
(7, 'cristiancostin05@gmail.com', '123', 'Marilena', 'Presecan', 'Aleea Modrogan 4', 'Bucuresti', 'Romania', ''),
(8, 'burzionut@yahoo.com', 'root', 'Cococ', 'asdf', 'asf', 'saf', 'Romania', ''),
(9, 'joldescostin@yahoo.com', 'root', 'Joldes', 'Costin', 'Strada Primaverii nr 9', 'Campeni', 'Romania', ''),
(10, 'admin@admin.com', 'root', 'Admin', '', '', '', 'Romania', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id_c`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id_p`);

--
-- Indexes for table `tari`
--
ALTER TABLE `tari`
  ADD PRIMARY KEY (`id_t`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_u`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id_c` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id_p` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tari`
--
ALTER TABLE `tari`
  MODIFY `id_t` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_u` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
